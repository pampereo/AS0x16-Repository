# Teledunet List Updater for Premium Users
AS0x16 XBMC/KODI plugins Repository

Install the plugin and give your username/password and the location to save the file.
