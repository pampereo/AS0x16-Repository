# AS0x16 Repo Zip file
AS0x16 XBMC/KODI plugins Repository

To install the ZIP-Repo File go to System > Addons > Install  from ZIP > "your file location"
